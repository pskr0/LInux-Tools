""" WICD core module. """
